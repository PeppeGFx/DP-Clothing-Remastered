return {
    toggle = false,
    defaultKey = "y",

    commands = true,
    allowincars = false,
    allowragdolled = false,
    allowinwater = false,

    position = { x = 70, y = 50 }, -- min: 0, max: 100 (%)

    activeColor = "rgba(251, 10, 30, 0.87)",
}
