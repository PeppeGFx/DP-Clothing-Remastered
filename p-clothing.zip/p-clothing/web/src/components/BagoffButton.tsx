import { fillColor, strokeColor } from "../data";
import BagOffImage from "../assets/images/bagoff.png";

type Props = {
  isActive: boolean;
  activeColor: string;
  handleAction: (name: string) => void;
};

export default function BagOffButton({
  handleAction,
  isActive,
  activeColor,
}: Props) {
  const cx = "9";
  const cy = "90";
  const imageSize = "3rem";

  return (
    <g onClick={() => handleAction("bagoff")} className="cursor-pointer group transition-transform">
  {/* Base circle */}
  <circle cx={`${cx}%`} cy={`${cy}%`} r="30" fill={fillColor} />

  {/* Main stroke */}
  <circle
    r={32}
    fill="none"
    cx={`${cx}%`}
    cy={`${cy}%`}
    strokeWidth={5}
    stroke={isActive ? activeColor : strokeColor}
  />

  {/* Hover stroke */}
  <circle
    r={32}
    fill="none"
    cx={`${cx}%`}
    cy={`${cy}%`}
    strokeWidth={5}
    className="opacity-0 group-hover:opacity-100 transition-opacity"
  />

  {/* Image */}
  <image
    href={BagOffImage}
    width={imageSize}
    height={imageSize}
    x={`calc(${cx}% - ${imageSize} / 2)`}
    y={`calc(${cy}% - ${imageSize} / 2)`}
    className={`origin-center transition-all duration-200
      ${isActive ? '' : 'grayscale'}
      group-hover:grayscale-0
      group-hover:scale-[1.005]
      group-active:scale-[1.005]`}
  />
</g>

  );
}
